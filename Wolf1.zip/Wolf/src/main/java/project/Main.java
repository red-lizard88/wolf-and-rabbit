package project;

public class Main {

    public static void main(String[] args) {
        Wolf ilya = new Wolf();
        System.out.println("Start: " + ilya);
        Position newPosition = ilya.move();
        ilya.setPosition(newPosition);
        
        System.out.println("End: " + ilya);

    }

}
