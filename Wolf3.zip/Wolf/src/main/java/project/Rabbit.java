package project;

public class Rabbit extends Animal{

    public Rabbit() {
        super("Кролик", 2, 0.45);



    }
}
