package project;

public class Wolf extends Animal {
    public Wolf() {


        super("Волк", 3, 50);

    }


}
