package project;

public class Constants {
    public static final int areaX = 5;
    public static final int areaY = 3;

}
