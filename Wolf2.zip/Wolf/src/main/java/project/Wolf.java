package project;

public class Wolf extends Animal{
    private String name;
    private Position position;

    public Wolf() {
        this.position = new Position(0, 0 );
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    @Override
    public String toString() {
        return "Wolf{" +
                "name='" + name + '\'' +
                ", position=" + position +
                '}';
    }

    @Override
    Position move() {
        int x = (int) ( Math.random() * 10 );
        int y = (int) ( Math.random() * 4 );
        return new Position(x, y);
    }
}
