package project;

public class Main {

    public static void main(String[] args) {
        Wolf ilya = new Wolf();
        ilya.setName("Илья");
        Wolf ann = new Wolf();
        ann.setName("Аня");
        System.out.println("Start: " + ilya);
        System.out.println("Start: " + ann);
        Position newPosition = ilya.move();
        Position newPosition2 = ann.move();
        ilya.setPosition(newPosition);
        ann.setPosition(newPosition2);

        System.out.println("End: " + ilya);
        System.out.println("End: " + ann);

    }

}
