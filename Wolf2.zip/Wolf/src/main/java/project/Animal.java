package project;

public abstract class Animal {

    abstract Position move();


}
